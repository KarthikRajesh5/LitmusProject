package com.ibs.training.ExpediaFlight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpediaFlightApplicationTests {

	@Test
	void contextLoads() {
	}

}
